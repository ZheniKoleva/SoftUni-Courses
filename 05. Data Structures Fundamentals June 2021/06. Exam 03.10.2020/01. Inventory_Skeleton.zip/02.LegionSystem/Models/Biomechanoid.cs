﻿namespace _02.LegionSystem.Models
{
    public class Biomechanoid : Enemy
    {
        public Biomechanoid(int attackSpeed, int health) 
            : base(attackSpeed, health)
        {
        }
    }
}
