﻿using System.Collections.Generic;

namespace Exam.DeliveriesManager
{
    public class DeliveriesManager : IDeliveriesManager
    {
        public void AddDeliverer(Deliverer deliverer)
        {
            throw new System.NotImplementedException();
        }

        public void AddPackage(Package package)
        {
            throw new System.NotImplementedException();
        }

        public void AssignPackage(Deliverer deliverer, Package package)
        {
            throw new System.NotImplementedException();
        }

        public bool Contains(Deliverer deliverer)
        {
            throw new System.NotImplementedException();
        }

        public bool Contains(Package package)
        {
            throw new System.NotImplementedException();
        }

        public IEnumerable<Deliverer> GetDeliverers()
        {
            throw new System.NotImplementedException();
        }

        public IEnumerable<Deliverer> GetDeliverersOrderedByCountOfPackagesThenByName()
        {
            throw new System.NotImplementedException();
        }

        public IEnumerable<Package> GetPackages()
        {
            throw new System.NotImplementedException();
        }

        public IEnumerable<Package> GetPackagesOrderedByWeightThenByReceiver()
        {
            throw new System.NotImplementedException();
        }

        public IEnumerable<Package> GetUnassignedPackages()
        {
            throw new System.NotImplementedException();
        }
    }
}
