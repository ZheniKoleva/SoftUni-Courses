﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace CouponOps
{
    public class CouponOperations : ICouponOperations
    {
        public CouponOperations()
        {
        }

        public void RegisterSite(Website w)
        {
        }

        public void AddCoupon(Website w, Coupon c)
        {
        }

        public Website RemoveWebsite(string domain)
        {
            return null;
        }

        public Coupon RemoveCoupon(string code)
        {
            return null;
        }

        public bool Exist(Website w)
        {
            return null;
        }

        public bool Exist(Coupon c)
        {
            return null;
        }

        public IEnumerable<Website> GetSites()
        {
            return null;
        }

        public IEnumerable<Coupon> GetCouponsForWebsite(Website w)
        {
            return null;
        }

        public void UseCoupon(Website w, Coupon c)
        {
        }

        public IEnumerable<Coupon> GetCouponsOrderedByValidityDescAndDiscountPercentageDesc()
        {
            return null;
        }

        public IEnumerable<Website> GetWebsitesOrderedByUserCountAndCouponsCountDesc()
        {
            return null;
        }
    }
}
