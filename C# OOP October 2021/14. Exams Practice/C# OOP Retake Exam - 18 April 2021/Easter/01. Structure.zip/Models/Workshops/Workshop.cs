﻿using System.Linq;

using Easter.Models.Dyes.Contracts;
using Easter.Models.Eggs.Contracts;
using Easter.Models.Bunnies.Contracts;
using Easter.Models.Workshops.Contracts;


namespace Easter.Models.Workshops
{
    public class Workshop : IWorkshop
    {
        public void Color(IEgg egg, IBunny bunny)
        {
            while (bunny.Energy > 0 && bunny.Dyes.Any(x => !x.IsFinished()))
            {
                IDye currentDye = bunny.Dyes.First(x => !x.IsFinished());

                bunny.Work();
                currentDye.Use();
                egg.GetColored();

                if (egg.IsDone())
                {
                    break;
                }
            }
        }
    }
}
