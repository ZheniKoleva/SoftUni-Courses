﻿namespace Aquariums.Tests
{
    using System;

    public class AquariumsTests
    {
    }
}
