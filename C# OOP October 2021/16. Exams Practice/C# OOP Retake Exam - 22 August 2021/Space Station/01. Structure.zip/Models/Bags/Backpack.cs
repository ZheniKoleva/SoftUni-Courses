﻿using System.Collections.Generic;

using SpaceStation.Models.Bags.Contracts;


namespace SpaceStation.Models.Bags
{
    public class Backpack : IBag
    {
        private readonly ICollection<string> items;

        public Backpack()
        {
            items = new HashSet<string>();
        }

        public ICollection<string> Items => items;
    }
}
