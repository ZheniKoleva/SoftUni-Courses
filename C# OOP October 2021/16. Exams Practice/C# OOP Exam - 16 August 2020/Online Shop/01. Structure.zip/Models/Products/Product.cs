﻿namespace OnlineShop.Models.Products
{
    public abstract class Product : IProduct
    {     
        public int Id => throw new System.NotImplementedException();

        public string Manufacturer => throw new System.NotImplementedException();

        public string Model => throw new System.NotImplementedException();

        public decimal Price => throw new System.NotImplementedException();

        public double OverallPerformance => throw new System.NotImplementedException();
    }
}
