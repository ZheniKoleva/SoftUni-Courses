﻿namespace OnlineShop.Models.Products.Components
{
    public class RandomAccessMemory : Component
    {
    }
}
