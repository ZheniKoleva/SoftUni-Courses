﻿namespace OnlineShop.Models.Products.Components
{
    public class Motherboard : Component
    {
    }
}
