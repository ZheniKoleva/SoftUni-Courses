﻿

namespace OnlineShop.Models.Products.Components
{
    public class VideoCard : Component
    {
    }
}
