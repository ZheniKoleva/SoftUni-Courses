﻿
namespace OnlineShop.Models.Products.Components
{
    public class CentralProcessingUnit : Component
    {
    }
}
