﻿namespace OnlineShop.Models.Products.Components
{
    public class PowerSupply : Component
    {
    }
}
