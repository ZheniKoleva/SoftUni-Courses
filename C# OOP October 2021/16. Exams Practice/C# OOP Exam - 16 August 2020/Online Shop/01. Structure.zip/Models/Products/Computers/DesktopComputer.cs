﻿
namespace OnlineShop.Models.Products.Computers
{
    public class DesktopComputer : Computer
    {
    }
}
