﻿namespace OnlineShop.Models.Products.Computers
{
    public class Laptop : Computer
    {
    }
}
