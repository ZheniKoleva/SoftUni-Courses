﻿namespace OnlineShop.Models.Products.Peripherals
{
    public class Headset : Peripheral
    {
    }
}
