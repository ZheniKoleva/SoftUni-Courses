﻿namespace OnlineShop.Models.Products.Peripherals
{
    public class Keyboard : Peripheral
    {
    }
}
