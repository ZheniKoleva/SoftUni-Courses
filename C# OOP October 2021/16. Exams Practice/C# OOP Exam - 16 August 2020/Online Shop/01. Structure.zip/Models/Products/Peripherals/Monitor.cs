﻿namespace OnlineShop.Models.Products.Peripherals
{
    public class Monitor : Peripheral
    {
    }
}
