function deleteByEmail() {
    console.log('TODO:...');
}