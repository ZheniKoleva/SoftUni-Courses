window.addEventListener('load', solve);

function solve() {
    //TO DO
}
