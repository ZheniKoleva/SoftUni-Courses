function solve() {

    function depart() {
        console.log('Depart TODO...');
    }

    function arrive() {
        console.log('Arrive TODO...');
    }

    return {
        depart,
        arrive
    };
}

let result = solve();