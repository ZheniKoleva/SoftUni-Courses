function getInfo() {
    console.log("TODO...");
}