using System;
using NUnit.Framework;

public class HeroRepositoryTests
{
    
}