﻿using System;
using System.Collections.Generic;
using System.Text;
using WarCroft.Entities.Inventory;
using WarCroft.Entities.Characters.Contracts;
using WarCroft.Constants;

namespace WarCroft.Entities.Characters
{
    public class Warrior : Character, IAttacker
    {
        private const double Default_BaseHealth = 100;

        private const double Default_BaseArmor = 50;

        private const double Default_AbilityPoints = 40;

        //private  IBag Default_Bag = new Satchel();

        public Warrior(string name) 
            : base(name, Default_BaseHealth, Default_BaseArmor, Default_AbilityPoints, new Satchel())
        {
        }

        public void Attack(Character character)
        {
            this.EnsureAlive();
           
            bool isCharacterAlive = character.IsAlive;

            if (!isCharacterAlive)
            {
                throw new InvalidOperationException(ExceptionMessages.AffectedCharacterDead);
            }

            if (character.Equals(this))
            {
                throw new InvalidOperationException(ExceptionMessages.CharacterAttacksSelf);
            }

            character.TakeDamage(this.AbilityPoints);
        }
    }
}
