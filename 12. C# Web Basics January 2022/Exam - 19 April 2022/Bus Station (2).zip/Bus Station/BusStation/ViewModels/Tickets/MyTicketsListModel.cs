﻿namespace BusStation.ViewModels.Tickets
{
    public class MyTicketsListModel
    {
        public string DestinationImage { get; set; }

        public string Destination { get; set; }

        public string SingleTicket { get; set; }

        public string DateAndTime { get; set; }

    }
}
