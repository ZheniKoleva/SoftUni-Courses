﻿namespace BusStation.ViewModels.Tickets
{
    public class MyTicketsListModel
    {
        public string DestinationImage { get; set; }

        public string Destination { get; set; }

        public string Price { get; set; }

        public string DateAndTime { get; set; }

    }
}
