﻿namespace SharedTrip.Data
{
    public class DatabaseConfiguration
    {
        public const string ConnectionString =
            @"Server=.;Database=FootballManager;Integrated Security = True;";
    }
}