﻿namespace _01.ListyIterator
{
    using System;
    using System.Collections.Generic;

    public class ListyIterator<T>
    {
        private readonly IList<T> data;

        private int indx = 0;

        public ListyIterator(params T[] collection)
        {
            data = new List<T>(collection);
        }

        public bool HasNext() => (indx + 1) < data.Count;

        public bool Move()
        {
            bool canMove = HasNext();

            if (canMove)
            {
                indx++;                
            }

            return canMove;
        }

        public void Print()
        {
            IsEmpty();
            
            Console.WriteLine(data[indx]);
            
        }

        private void IsEmpty()
        {
            if (data.Count == 0)
            {
                throw new InvalidOperationException("Invalid Operation!");
            }
        }
    }
}
