﻿using System;
using System.Linq;

namespace _04.Froggy
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Lake<int> stones = new Lake<int>(Console.ReadLine()
                                              .Split(", ", StringSplitOptions.RemoveEmptyEntries)
                                              .Select(int.Parse));

            Console.WriteLine(string.Join(", ", stones));
        }
    }
}
