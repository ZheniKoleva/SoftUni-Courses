﻿using System;

namespace GenericCountMethod
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            int linesCount = int.Parse(Console.ReadLine());

            Box<string> collection = new Box<string>();

            for (int i = 0; i < linesCount; i++)
            {
                collection.Add(Console.ReadLine());
            }

            string elementToCompare = Console.ReadLine();
            Console.WriteLine(collection.CountMethod(elementToCompare));
        }
    }
}
