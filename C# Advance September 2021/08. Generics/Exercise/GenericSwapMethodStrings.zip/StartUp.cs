﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace GenericSwapMethod
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            int linesCount = int.Parse(Console.ReadLine());

            List<Box<string>> strings = new List<Box<string>>();

            for (int i = 0; i < linesCount; i++)
            {
                strings.Add(new Box<string>(Console.ReadLine()));
            }

            int[] indxesToSwap = Console.ReadLine()
                .Split(' ', StringSplitOptions.RemoveEmptyEntries)
                .Select(int.Parse)
                .ToArray();

            Swap(strings, indxesToSwap[0], indxesToSwap[1]);
            strings.ForEach(Console.WriteLine);
        }

        private static void Swap<T>(List<Box<T>> items, int firstIndx, int secondIndx)
        {
            Box<T> temp = items[firstIndx];
            items[firstIndx] = items[secondIndx];
            items[secondIndx] = temp;
        }
    }
}
