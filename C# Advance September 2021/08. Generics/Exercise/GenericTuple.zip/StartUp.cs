﻿using System;

namespace GenericTuple
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            string[] data = ReadData();

            string name = string.Join(' ', data[0..2]);
            Tuple<string, string> firstTuple = new Tuple<string, string>(name, data[2]);
            Console.WriteLine(firstTuple);

            data = ReadData();
            Tuple<string, int> secondTuple = new Tuple<string, int>(data[0], int.Parse(data[1]));
            Console.WriteLine(secondTuple);

            data = ReadData();
            Tuple<int, double> thirdTuple = new Tuple<int, double>(int.Parse(data[0]), double.Parse(data[1]));
            Console.WriteLine(thirdTuple);
        }

        private static string[] ReadData()
        {
            return Console.ReadLine()
                .Split(' ', StringSplitOptions.RemoveEmptyEntries);
        }
    }
}
