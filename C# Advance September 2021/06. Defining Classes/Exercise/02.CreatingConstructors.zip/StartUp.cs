﻿using System;

namespace DefiningClasses
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Person first = new Person();

            Person second = new Person(18);

            Person third = new Person("Peter", 20);
        }
    }
}
