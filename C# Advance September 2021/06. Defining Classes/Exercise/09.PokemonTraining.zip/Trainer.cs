﻿namespace _09.PokemonTrainer
{
    using System.Collections.Generic;

    public class Trainer
    {
        public Trainer(string name)
        {
            Name = name;
            Badges = 0;
            Pokemons = new List<Pokemon>();
        }

        public string Name { get; set; }

        public int Badges { get; set; }

        public List<Pokemon> Pokemons { get; set; }

        public void ReducePokemonHealthBy10()
        {
            for (int i = 0; i < Pokemons.Count; i++)
            {
                Pokemons[i].Health -= 10;

                if (Pokemons[i].Health <= 0)
                {
                    Pokemons.RemoveAt(i);
                    i--;
                }
            }
        }

        public override string ToString() => $"{Name} {Badges} {Pokemons.Count}";       
    }
}
