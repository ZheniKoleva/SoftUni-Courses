﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace GenericSwapMethod
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            int linesCount = int.Parse(Console.ReadLine());

            //List<Box<string>> collection = new List<Box<string>>();
            List<Box<int>> collection = new List<Box<int>>();

            for (int i = 0; i < linesCount; i++)
            {
                //collection.Add(new Box<string>(Console.ReadLine()));
                collection.Add(new Box<int>(int.Parse(Console.ReadLine())));
            }

            int[] indxesToSwap = Console.ReadLine()
                .Split(' ', StringSplitOptions.RemoveEmptyEntries)
                .Select(int.Parse)
                .ToArray();

            Swap(collection, indxesToSwap[0], indxesToSwap[1]);
            collection.ForEach(Console.WriteLine);
        }

        private static void Swap<T>(List<Box<T>> items, int firstIndx, int secondIndx)
        {
            Box<T> temp = items[firstIndx];
            items[firstIndx] = items[secondIndx];
            items[secondIndx] = temp;
        }
    }
}
