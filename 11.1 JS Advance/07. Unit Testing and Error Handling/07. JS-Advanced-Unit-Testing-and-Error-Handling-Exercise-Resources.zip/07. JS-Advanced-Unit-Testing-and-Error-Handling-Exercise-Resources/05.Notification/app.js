function notify(message) {
  console.log('todo')
  // TODO:
}