﻿namespace SoftJail.DataProcessor.ExportDto
{
    public class ExportOfficerDTO
    {
        public string OfficerName { get; set; }

        public string Department { get; set; }
    }
}