﻿namespace VaporStore.Data.Models
{
    using System.Collections.Generic;

    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;

    using Common;
    using Data.Models.Enums;

    public class Card
    {
        public Card()
        {
            Purchases = new HashSet<Purchase>();
        }

        [Key]
        public int Id { get; set; }

        [Required]
        [RegularExpression(EntityConstants.Card_Number_Regex_Pattern)]
        public string Number { get; set; }

        [Required]
        [RegularExpression(EntityConstants.Card_Cvc_Regex_Pattern)]
        public string Cvc { get; set; }

        [Range(EntityConstants.Card_Type_Min_Value, EntityConstants.Card_Type_Max_Value)]
        public CardType Type { get; set; }

        [ForeignKey(nameof(User))]
        public int UserId { get; set; }
        public virtual User User { get; set; }

        public virtual ICollection<Purchase> Purchases { get; set; }
    }

//•	Id – integer, Primary Key
//•	Number – text, which consists of 4 pairs of 4 digits, separated by spaces(ex. “1234 5678 9012 3456”) (required)
//•	Cvc – text, which consists of 3 digits(ex. “123”) (required)
//•	Type – enumeration of type CardType, with possible values(“Debit”, “Credit”) (required)
//•	UserId – integer, foreign key(required)
//•	User – the card’s user(required)
//•	Purchases – collection of type Purchase

}
