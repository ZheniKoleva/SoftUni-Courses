﻿namespace VaporStore.Data.Models
{
    using System;
    using System.Collections.Generic;

    using System.ComponentModel.DataAnnotations;

    using VaporStore.Common;

    public class User
    {
        public User()
        {
            Cards = new HashSet<Card>();
        }

        [Key]
        public int Id { get; set; }

        [Required]
        [StringLength(EntityConstants.User_Username_Max_Length)]
        public string Username { get; set; }

        [Required]
        [RegularExpression(EntityConstants.User_FullName_Regex_Pattern)]
        public string FullName { get; set; }

        [Required]
        public string Email { get; set; }

        [Range(EntityConstants.User_Age_Min_Value, EntityConstants.User_Age_Max_Value)]
        public int Age { get; set; }

        public virtual ICollection<Card> Cards { get; set; }

    }

//•	Id – integer, Primary Key
//•	Username – text with length[3, 20] (required)
//•	FullName – text, which has two words, consisting of Latin letters.Both start with an upper letter and are followed by lower letters.The two words are separated by a single space (ex. "John Smith") (required)
//•	Email – text(required)
//•	Age – integer in the range[3, 103] (required)
//•	Cards – collection of type Card

}
